
<!-- jquery-->  
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/jquery-2.2.4.min.js')?>" type="text/javascript"></script>

        <!-- Plugins js -->
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/plugins.js')?>" type="text/javascript"></script>
        
        <!-- Bootstrap js -->
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/bootstrap.min.js')?>" type="text/javascript"></script>

        <!-- WOW JS -->     
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/wow.min.js')?>"></script>

        <!-- Nivo slider js -->     
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/vendor/slider/js/jquery.nivo.slider.js')?>" type="text/javascript"></script>
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/vendor/slider/home.js')?>" type="text/javascript"></script>

        <!-- Owl Cauosel JS -->
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/vendor/OwlCarousel/owl.carousel.min.js')?>" type="text/javascript"></script>
        
        <!-- Meanmenu Js -->
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/jquery.meanmenu.min.js')?>" type="text/javascript"></script>

        <!-- Srollup js -->
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/jquery.scrollUp.min.js')?>" type="text/javascript"></script>

         <!-- jquery.counterup js -->
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/jquery.counterup.min.js')?>"></script>
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/waypoints.min.js')?>"></script>

        <!-- Countdown js -->
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/jquery.countdown.min.js')?>" type="text/javascript"></script>

        <!-- Isotope js -->
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/isotope.pkgd.min.js')?>" type="text/javascript"></script>

        <!-- Magic Popup js -->
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/jquery.magnific-popup.min.js')?>" type="text/javascript"></script>
        
        <!-- Custom Js -->
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/main.js')?>" type="text/javascript"></script>

    </body>
</html>
