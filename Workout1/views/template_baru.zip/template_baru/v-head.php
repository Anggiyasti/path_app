
</div>  
    <script src="<?php echo base_url('assets/app/halo/js/jquery-2.1.0.min.js')?>"></script>
    <script src="<?php echo base_url('assets/app/halo/js/jquery.swipebox.min.js')?>"></script>   
    <script src="<?php echo base_url('assets/app/halo/js/jquery.smoothState.min.js')?>"></script> 
    <script src="<?php echo base_url('assets/app/halo/js/materialize.min.js')?>"></script> 
    <script src="<?php echo base_url('assets/app/halo/js/swiper.min.js')?>"></script>  
    <script src="<?php echo base_url('assets/app/halo/js/jquery.mixitup.min.js')?>"></script>
    
    <script src="<?php echo base_url('assets/app/halo/js/masonry.min.js')?>"></script>

    <script src="<?php echo base_url('assets/app/halo/js/functions.js')?>"></script>
<!-- jquery-->  
        <script src="<?php echo base_url('assets/main-academics/academics-placeholder/js/jquery-2.2.4.min.js')?>" type="text/javascript"></script>

       
        
        
        

    </body>
</html>
